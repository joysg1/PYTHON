from PIL import Image, ImageColor, ImageDraw

# Crear una imagen de 400x400 píxeles con fondo blanco
image = Image.new('RGB', (400, 400), ImageColor.getrgb('white'))

# Crear un objeto ImageDraw para dibujar en la imagen
draw = ImageDraw.Draw(image)

# Función para dibujar un corazón
def draw_heart(draw, x, y, size, color):
    # Parámetros para la ecuación del corazón
    a = size
    b = size

    # Ecuación del corazón
    heart_points = []
    for t in range(0, 360):
        t_rad = t * 3.14159 / 180
        x_cor = x + a * 16 * pow(math.sin(t_rad), 3)
        y_cor = y - b * (13 * math.cos(t_rad) - 5 * math.cos(2 * t_rad) - 2 * math.cos(3 * t_rad) - math.cos(4 * t_rad))
        heart_points.append((x_cor, y_cor))

    # Dibujar el corazón
    draw.polygon(heart_points, fill=color)

import math

# Dibujar un corazón rojo en la imagen
draw_heart(draw, 200, 200, 10, ImageColor.getrgb('red'))

# Mostrar la imagen
image.show()











