from PIL import Image, ImageDraw, ImageFont
import matplotlib.pyplot as plt

# Cargar la imagen
im = Image.open(r"/home/userlm/Documentos/IMAGE_EDIT/L.jpg")

d1 = ImageDraw.Draw(im)

myFont = ImageFont.truetype(r'/usr/share/fonts/TTF/TSCu_Times.ttf', 50)

d1.text((50, 50), "En honor a los caidos",font=myFont, fill=(255, 0, 0))

im.show()

# Guardar la imagen modificada
im.save(r"/home/userlm/Documentos/IMAGE_EDIT/Lmodified.jpg")
