from PIL import Image, ImageDraw, ImageFont
import matplotlib.pyplot as plt

# Cargar la imagen
im = Image.open(r"/home/userlm/Documentos/IMAGE_CROP/L.jpg")


# Crop

box = (20, 20, 250, 300)

cropped_image = im.crop(box)


cropped_image.show()
cropped_image.save("cropped_image.jpg")

# Paste

im.paste(cropped_image, (100, 100))
im.paste(cropped_image, (200, 200))
im.show()



