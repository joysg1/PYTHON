from PIL import Image, ImageColor

image = Image.new('RGB', (400, 400), ImageColor.getrgb('white'))

width, height = image.size

for x in range(width):
    # Calcula el valor del color rojo y negro en función de x
    r = int(255 * (1 - x / width))  # Cambia el rojo de 255 a 0
    color = (r, 0, 0)  # Color en formato RGB

    # Pinta una línea gruesa en la diagonal
    for y in range(max(0, x-2), min(height, x+3)):
        if abs(y - x) <= 2:
            image.putpixel((x, y), color)

    # Pinta una línea gruesa en la antidiagonal
    for y in range(max(0, height-x-2), min(height, height-x+3)):
        if abs(y - (height - x - 1)) <= 2:
            image.putpixel((x, y), color)

image.show()










