from PIL import Image, ImageOps
import matplotlib.pyplot as plt

# Cargar la imagen
im = Image.open(r"/home/userlm/Documentos/IMAGE_TRANSFORMATIONS/L.jpg")

# Rotar la imagen
im = im.rotate(45)
im.show()

# Redimensionar la imagen
im = im.resize((100,100))
im.show()

# Guardar la imagen
im.save(r"/home/userlm/Documentos/IMAGE_TRANSFORMATIONS/L_transformed.jpg")
