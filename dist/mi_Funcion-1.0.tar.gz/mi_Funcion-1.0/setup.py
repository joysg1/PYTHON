from setuptools import setup

setup (
    name="mi_Funcion",
    version ="1.0",
    description="suma y par",
    author = "joysg1",
    author_email = "joy.nelaton@utp.ac.pa",
    urt="https://github.com/joysg1?tab=repositories",
    packages = ["Paquetes"]
    
    
    
)