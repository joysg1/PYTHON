def esPar(numero):
    if numero %2==0:
        return True
    else:
        return False
    
def suma(num1,num2):
    result = num1 + num2
    return result    