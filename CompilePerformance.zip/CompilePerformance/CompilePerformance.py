import time
import ctypes
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

# Cargar la librería compartida
lib = ctypes.CDLL('./suma.so')  # En Linux/Mac
# lib = ctypes.CDLL('./suma.dll')  # En Windows

# Definir el tipo de retorno y argumentos de la función suma
lib.suma.argtypes = [ctypes.c_int]
lib.suma.restype = ctypes.c_int

# Función en Python puro
def python_puro(n):
    resultado = 0
    for i in range(1, n+1):
        resultado += i
    return resultado

# Función utilizando ctypes
def ctypes_suma(n):
    return lib.suma(n)

# Mediciones
tiempos_python = []
tiempos_ctypes = []
iteraciones = [100, 500, 1000, 2000, 3000, 4000, 5000]

for n in iteraciones:
    start_time = time.time()
    python_puro(n)
    end_time = time.time()
    tiempos_python.append(end_time - start_time)
    
    start_time = time.time()
    ctypes_suma(n)
    end_time = time.time()
    tiempos_ctypes.append(end_time - start_time)

# Creación del gráfico
sns.set()
plt.figure(figsize=(10,6))
plt.plot(iteraciones, tiempos_python, label='Python puro')
plt.plot(iteraciones, tiempos_ctypes, label='ctypes')
plt.xlabel('Número de iteraciones')
plt.ylabel('Tiempo de ejecución (segundos)')
plt.title('Comparación de tiempos de ejecución')
plt.legend()
plt.grid(True)
plt.show()
