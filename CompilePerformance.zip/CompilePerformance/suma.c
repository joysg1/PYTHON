#include <stdio.h>

int suma(int n) {
    int resultado = 0;
    for (int i = 1; i <= n; i++) {
        resultado += i;
    }
    return resultado;
}
