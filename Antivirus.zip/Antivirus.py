import os
import hashlib

db = ['2c3ccd32927839768639b88829a5c04a',
      'a1b2c3d4e5f6789012345678901234ab'
      ]


def check(signature, efile):
   print(f"{signature}")
   if signature in db:
      print(f'Malware found = {efile}')

file_list = os.listdir(".")


for efile in file_list:
    if ".exe" in efile:
     print(efile, end='')
     result = hashlib.md5(efile.encode())
     signature = (result.hexdigest())
     check(signature, efile)