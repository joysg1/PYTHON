from PIL import Image
import matplotlib.pyplot as plt

# Cargar la imagen
im = Image.open(r"/home/userlm/Documentos/IMAGE_SAFE/L.jpg")

# Crear una figura y un eje
fig, ax = plt.subplots()

# Mostrar la imagen
ax.imshow(im)

# Agregar texto con la información de la imagen
ax.text(0.05, 0.95, f"Formato: {im.format}", transform=ax.transAxes, fontsize=12, color='yellow')
ax.text(0.05, 0.88, f"Tamaño: {im.size}", transform=ax.transAxes, fontsize=12, color='yellow')
ax.text(0.05, 0.81, f"Modo: {im.mode}", transform=ax.transAxes, fontsize=12, color='yellow')
ax.text(0.05, 0.74, f"Ancho: {im.width}", transform=ax.transAxes, fontsize=12, color='yellow')
ax.text(0.05, 0.67, f"Alto: {im.height}", transform=ax.transAxes, fontsize=12, color='yellow')

# Desactivar ejes
ax.axis('off')

# Guardar la figura en formato PNG
plt.savefig('imagen_con_texto.png', bbox_inches='tight', dpi=300)

# Mostrar la figura
plt.show()

