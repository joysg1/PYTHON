from PIL import Image, ImageFilter, ImageTk
import tkinter as tk
from tkinter import filedialog

class Aplicacion:
    def __init__(self, root):
        self.root = root
        self.root.title("Efectos de Imagen")
        self.imagen_path = None
        self.imagen_original = None
        self.imagen = None
        self.imagen_tk = None

        # Botón para cargar la imagen
        self.botón_cargar = tk.Button(root, text="Cargar Imagen", command=self.cargar_imagen)
        self.botón_cargar.pack()

        # Botón para aplicar efectos
        self.botón_efecto = tk.Button(root, text="Aplicar Efecto", command=self.aplicar_efecto)
        self.botón_efecto.pack()

        # Botón para resetear la imagen
        self.botón_reset = tk.Button(root, text="Resetear Imagen", command=self.resetear_imagen, state=tk.DISABLED)
        self.botón_reset.pack()

        # Botón para guardar la imagen
        self.botón_guardar = tk.Button(root, text="Guardar Imagen", command=self.guardar_imagen, state=tk.DISABLED)
        self.botón_guardar.pack()

        # Etiqueta para mostrar la imagen
        self.etiqueta_imagen = tk.Label(root)
        self.etiqueta_imagen.pack()

        # Variable para almacenar el efecto seleccionado
        self.efecto_seleccionado = tk.StringVar(root)
        self.efecto_seleccionado.set("seleccionar")

        # Opciones para el efecto
        self.opciones_efecto = ["seleccionar", "BLUR", "EDGE_ENHANCE", "GaussianBlur", "CONTOUR", "EMBOSS", "SHARPEN", "SMOOTH"]

        # Menú desplegable para seleccionar el efecto
        self.menú_efecto = tk.OptionMenu(root, self.efecto_seleccionado, *self.opciones_efecto)
        self.menú_efecto.pack()

    def cargar_imagen(self):
        self.imagen_path = filedialog.askopenfilename(filetypes=[("Archivos de imagen", ".jpg .jpeg .png .bmp")])
        if self.imagen_path:
            self.imagen_original = Image.open(self.imagen_path)
            self.imagen = self.imagen_original.copy()
            self.imagen_tk = ImageTk.PhotoImage(self.imagen)
            self.etiqueta_imagen.config(image=self.imagen_tk)
            self.botón_reset.config(state=tk.DISABLED)
            self.botón_guardar.config(state=tk.NORMAL)

    def aplicar_efecto(self):
        if self.imagen:
            efecto = self.efecto_seleccionado.get()
            if efecto == "BLUR":
                self.imagen = self.imagen_original.filter(ImageFilter.BLUR)
            elif efecto == "EDGE_ENHANCE":
                self.imagen = self.imagen_original.filter(ImageFilter.EDGE_ENHANCE)
            elif efecto == "GaussianBlur":
                self.imagen = self.imagen_original.filter(ImageFilter.GaussianBlur(15))
            elif efecto == "CONTOUR":
                self.imagen = self.imagen_original.filter(ImageFilter.CONTOUR)
            elif efecto == "EMBOSS":
                self.imagen = self.imagen_original.filter(ImageFilter.EMBOSS)
            elif efecto == "SHARPEN":
                self.imagen = self.imagen_original.filter(ImageFilter.SHARPEN)
            elif efecto == "SMOOTH":
                self.imagen = self.imagen_original.filter(ImageFilter.SMOOTH)

            self.imagen_tk = ImageTk.PhotoImage(self.imagen)
            self.etiqueta_imagen.config(image=self.imagen_tk)
            self.botón_reset.config(state=tk.NORMAL)

    def resetear_imagen(self):
        if self.imagen_original:
            self.imagen = self.imagen_original.copy()
            self.imagen_tk = ImageTk.PhotoImage(self.imagen)
            self.etiqueta_imagen.config(image=self.imagen_tk)
            self.botón_reset.config(state=tk.DISABLED)

    def guardar_imagen(self):
        if self.imagen:
            path_guardar = filedialog.asksaveasfilename(defaultextension=".jpg", filetypes=[("Archivos de imagen", ".jpg .jpeg .png .bmp")])
            if path_guardar:
                self.imagen.save(path_guardar)

if __name__ == "__main__":
    root = tk.Tk()
    app = Aplicacion(root)
    root.mainloop()







