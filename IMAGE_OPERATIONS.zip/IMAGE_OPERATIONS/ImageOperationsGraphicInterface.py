from PIL import Image, ImageOps, ImageTk
import tkinter as tk
from tkinter import filedialog

class Aplicacion:
    def __init__(self, root):
        self.root = root
        self.image_path = None
        self.image = None
        self.photo = None

        # Botón para cargar la imagen
        self.button_cargar = tk.Button(self.root, text="Cargar Imagen", command=self.cargar_imagen)
        self.button_cargar.pack()

        # Botones para aplicar operaciones
        self.button_voltear = tk.Button(self.root, text="Voltear", command=self.voltear)
        self.button_voltear.pack()

        self.button_espejo = tk.Button(self.root, text="Espejo", command=self.espejo)
        self.button_espejo.pack()

        self.button_grises = tk.Button(self.root, text="Escala de Grises", command=self.grises)
        self.button_grises.pack()

        self.button_invertir = tk.Button(self.root, text="Invertir", command=self.invertir)
        self.button_invertir.pack()

        # Label para mostrar la imagen
        self.imagelabel = tk.Label(self.root)
        self.imagelabel.pack()

    def cargar_imagen(self):
        self.image_path = filedialog.askopenfilename(filetypes=[("Imagenes", ".jpg .jpeg .png .bmp")])
        if self.image_path:
            self.image = Image.open(self.image_path)
            self.photo = ImageTk.PhotoImage(self.image)
            self.imagelabel.config(image=self.photo)

    def voltear(self):
        if self.image:
            self.image = ImageOps.flip(self.image)
            self.photo = ImageTk.PhotoImage(self.image)
            self.imagelabel.config(image=self.photo)

    def espejo(self):
        if self.image:
            self.image = ImageOps.mirror(self.image)
            self.photo = ImageTk.PhotoImage(self.image)
            self.imagelabel.config(image=self.photo)

    def grises(self):
        if self.image:
            self.image = ImageOps.grayscale(self.image)
            self.photo = ImageTk.PhotoImage(self.image)
            self.imagelabel.config(image=self.photo)

    def invertir(self):
        if self.image:
            self.image = ImageOps.invert(self.image)
            self.photo = ImageTk.PhotoImage(self.image)
            self.imagelabel.config(image=self.photo)

if __name__ == "__main__":
    root = tk.Tk()
    app = Aplicacion(root)
    root.mainloop()
