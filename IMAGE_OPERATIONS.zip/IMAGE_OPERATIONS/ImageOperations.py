from PIL import Image, ImageOps
import matplotlib.pyplot as plt

# Cargar la imagen
im = Image.open(r"/home/userlm/Documentos/IMAGE_OPERATIONS/L.jpg")

im= ImageOps.flip(im)

im.show()

im = ImageOps.mirror(im)

im.show()

im = ImageOps.grayscale(im)

im.show()

im = ImageOps.invert(im)

im.show()